This copy of the Caver plugin is based on caver_3.0_plugin.zip (3.0.1) and
modified to work on Windows, Linux and macOS out of the box (if Java is
installed), using the same code.

Install caver_plugin_301u.zip with the PyMOL plugin manager.

Modifications dumped to "universal.patch" for reference.

Modifications published under the same license like the Caver plugin
(currently GPL).

Modifications are (C) Thomas Holder, Schrodinger Inc.

2017-08-22
